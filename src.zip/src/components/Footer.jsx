// src/components/Footer.jsx
import { Link } from 'react-router-dom';
import { ShoppingBag, Mail, Phone, Clock } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <h3 className="footer-title">Blibeli Store</h3>
            <p className="footer-text">
              Premium online shopping experience with quality products and excellent service.
            </p>
          </div>
          
          <div className="footer-section">
            <h3 className="footer-title">Quick Links</h3>
            <ul className="footer-links">
              <li><Link to="/" className="footer-link"><ShoppingBag size={14} /> Home</Link></li>
              <li><Link to="/products" className="footer-link"><ShoppingBag size={14} /> Products</Link></li>
              <li><Link to="/cart" className="footer-link"><ShoppingBag size={14} /> Cart</Link></li>
              <li><Link to="/login" className="footer-link"><ShoppingBag size={14} /> Login</Link></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h3 className="footer-title">Contact Us</h3>
            <ul className="footer-links">
              <li className="footer-link">
                <Mail size={14} />
                support@blibeli.com
              </li>
              <li className="footer-link">
                <Phone size={14} />
                (123) 456-7890
              </li>
              <li className="footer-link">
                <Clock size={14} />
                9AM-6PM Mon-Fri
              </li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h3 className="footer-title">Newsletter</h3>
            <p className="footer-text">Subscribe for updates and promotions.</p>
            <div className="newsletter-form">
              <input type="email" placeholder="Your email" className="newsletter-input" />
              <button className="newsletter-btn">Subscribe</button>
            </div>
          </div>
        </div>
        
        <hr className="footer-divider" />
        
        <div className="footer-bottom">
          <p>© 2025 Blibeli Store. All rights reserved.</p>
          <div className="footer-social">
            <a href="#" className="social-link">Facebook</a>
            <a href="#" className="social-link">Instagram</a>
            <a href="#" className="social-link">Twitter</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;