// src/components/Header.js
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { ShoppingCart, Menu, User, LogOut, LogIn, Home, Package, BarChart3, Users, Settings } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const Header = () => {
  const { getTotalItems } = useCart();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  const handleLogout = async () => {
    await logout();
    setShowLogoutModal(false);
    navigate('/');
  };

  return (
    <>
      <header className="header">
        <nav className="nav container">
          <Link to="/" className="logo">
            <span className="logo-icon"></span>
            Blibeli
          </Link>
          
          <div className="nav-links">
            {user && user.role === 'admin' ? (
              <>
                <Link to="/admin/dashboard" className="nav-link">
                  <BarChart3 size={16} />
                  Dashboard
                </Link>
                <Link to="/admin/Report" className="nav-link">
                  <ShoppingCart size={16} />
                  Report
                </Link>
              </>
            ) : (
              // Customer/Guest Navigation
              <>
                <Link to="/" className="nav-link">
                  <Home size={16} />
                  Home
                </Link>
                <Link to="/products" className="nav-link">
                  <Package size={16} />
                  Products
                </Link>
                <Link to="/cart" className="nav-link">
                  <ShoppingCart size={16} />
                  Cart
                </Link>
                {user && (
                  <Link to="/profile" className="nav-link">
                    <User size={16} />
                    Profile
                  </Link>
                )}
              </>
            )}
            
            {user ? (
              <button
                onClick={() => setShowLogoutModal(true)}
                className="nav-link logout-btn"
              >
                <LogOut size={16} />
                Logout ({user.name})
              </button>
            ) : (
              <Link to="/login" className="nav-link login-btn">
                <LogIn size={16} />
                Login
              </Link>
            )}
          </div>
          
          <div className="cart-wrapper">
            {(!user || user.role === 'customer') && (
              <Link to="/cart" className="cart-icon">
                <ShoppingCart size={22} color="#4b5563" />
                {getTotalItems() > 0 && (
                  <span className="cart-badge">
                    {getTotalItems()}
                  </span>
                )}
              </Link>
            )}
            
            <button className="mobile-menu-btn">
              <Menu size={24} color="#4b5563" />
            </button>
          </div>
        </nav>
      </header>

      {/* Logout Confirmation Modal */}
      {showLogoutModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Confirm Logout</h3>
              <button 
                className="modal-close"
                onClick={() => setShowLogoutModal(false)}
              >
                ×
              </button>
            </div>
            <div className="modal-body">
              <p>Are you sure you want to logout?</p>
            </div>
            <div className="modal-footer">
              <button 
                className="btn btn-secondary"
                onClick={() => setShowLogoutModal(false)}
              >
                Cancel
              </button>
              <button 
                className="btn remove-btn"
                onClick={handleLogout}
              >
                Yes, Logout
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Header;