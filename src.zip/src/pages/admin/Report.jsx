import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  BarChart3, Package, ShoppingCart, Users, DollarSign, 
  TrendingUp, TrendingDown, PlusCircle, FileText, Settings,
  Eye, MoreVertical, Calendar, CreditCard, Truck, CheckCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const AdminDashboard = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  
  // Data stats dari state
  const [stats, setStats] = useState({
    totalSales: 45820,
    totalOrders: 342,
    totalProducts: 156,
    totalCustomers: 289,
    monthlyGrowth: 12.5,
    conversionRate: 4.2
  });


  // Monthly sales data untuk chart
  const [monthlyData, setMonthlyData] = useState([
    { month: 'Jan', sales: 12000, orders: 45 },
    { month: 'Feb', sales: 18000, orders: 62 },
    { month: 'Mar', sales: 15000, orders: 54 },
    { month: 'Apr', sales: 22000, orders: 78 },
    { month: 'May', sales: 19000, orders: 65 },
    { month: 'Jun', sales: 25000, orders: 89 },
    { month: 'Jul', sales: 28000, orders: 95 },
    { month: 'Aug', sales: 32000, orders: 112 },
    { month: 'Sep', sales: 29000, orders: 98 },
    { month: 'Oct', sales: 35000, orders: 125 },
    { month: 'Nov', sales: 40000, orders: 142 },
    { month: 'Dec', sales: 45820, orders: 342 },
  ]);


  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const getStatusIcon = (status) => {
    switch(status) {
      case 'completed': return <CheckCircle size={14} color="#059669" />;
      // case 'pending': return <Clock size={14} color="#d97706" />;
      case 'shipped': return <Truck size={14} color="#2563eb" />;
      default: return <MoreVertical size={14} />;
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'completed': return '#d1fae5';
      case 'pending': return '#fef3c7';
      case 'shipped': return '#dbeafe';
      default: return '#f3f4f6';
    }
  };

  const getStatusTextColor = (status) => {
    switch(status) {
      case 'completed': return '#065f46';
      case 'pending': return '#92400e';
      case 'shipped': return '#1e40af';
      default: return '#374151';
    }
  };

  // Calculate additional stats
  const averageOrderValue = stats.totalSales / stats.totalOrders;
  const orderCompletionRate = (recentOrders.filter(o => o.status === 'completed').length / recentOrders.length) * 100;

  if (!user || user.role !== 'admin') {
    return (
      <div className="empty-state">
        <div className="empty-icon">🚫</div>
        <h2 className="empty-title">Access Denied</h2>
        <p className="empty-text">You don't have permission to access this page.</p>
        <Link to="/login/admin" className="btn btn-primary">
          Admin Login
        </Link>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
        <p>Loading dashboard data...</p>
      </div>
    );
  }}
  