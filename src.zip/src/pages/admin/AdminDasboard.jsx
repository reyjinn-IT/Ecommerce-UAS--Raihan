// src/pages/admin/AdminDashboard.js
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  BarChart3, Package, ShoppingCart, Users, DollarSign, 
  TrendingUp, TrendingDown, PlusCircle, FileText, Settings,
  Eye, MoreVertical, Calendar, CreditCard, Truck, CheckCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const AdminDashboard = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  
  // Data stats dari state
  const [stats, setStats] = useState({
    totalSales: 45820,
    totalOrders: 342,
    totalProducts: 156,
    totalCustomers: 289,
    monthlyGrowth: 12.5,
    conversionRate: 4.2
  });

  // Recent orders data
  const [recentOrders, setRecentOrders] = useState([
    { id: 'ORD-001', customer: 'John Doe', amount: 249.99, status: 'completed', date: '2024-01-15' },
    { id: 'ORD-002', customer: 'Jane Smith', amount: 149.50, status: 'pending', date: '2024-01-15' },
    { id: 'ORD-003', customer: 'Bob Johnson', amount: 89.99, status: 'completed', date: '2024-01-14' },
    { id: 'ORD-004', customer: 'Alice Brown', amount: 299.99, status: 'shipped', date: '2024-01-14' },
    { id: 'ORD-005', customer: 'Charlie Wilson', amount: 79.99, status: 'pending', date: '2024-01-13' },
    { id: 'ORD-006', customer: 'David Lee', amount: 189.99, status: 'completed', date: '2024-01-13' },
    { id: 'ORD-007', customer: 'Emma Davis', amount: 399.99, status: 'completed', date: '2024-01-12' },
    { id: 'ORD-008', customer: 'Frank Miller', amount: 129.99, status: 'shipped', date: '2024-01-12' },
  ]);

  // Monthly sales data untuk chart
  const [monthlyData, setMonthlyData] = useState([
    { month: 'Jan', sales: 12000, orders: 45 },
    { month: 'Feb', sales: 18000, orders: 62 },
    { month: 'Mar', sales: 15000, orders: 54 },
    { month: 'Apr', sales: 22000, orders: 78 },
    { month: 'May', sales: 19000, orders: 65 },
    { month: 'Jun', sales: 25000, orders: 89 },
    { month: 'Jul', sales: 28000, orders: 95 },
    { month: 'Aug', sales: 32000, orders: 112 },
    { month: 'Sep', sales: 29000, orders: 98 },
    { month: 'Oct', sales: 35000, orders: 125 },
    { month: 'Nov', sales: 40000, orders: 142 },
    { month: 'Dec', sales: 45820, orders: 342 },
  ]);

  // Top selling products
  const [topProducts, setTopProducts] = useState([
    { id: 1, name: 'Premium Headphones', category: 'Electronics', sales: 124, revenue: 12400 },
    { id: 2, name: 'Smart Watch Pro', category: 'Wearables', sales: 98, revenue: 19600 },
    { id: 3, name: 'Wireless Mouse', category: 'Accessories', sales: 156, revenue: 4680 },
    { id: 4, name: 'USB-C Cable', category: 'Accessories', sales: 230, revenue: 1150 },
    { id: 5, name: 'Laptop Stand', category: 'Office', sales: 87, revenue: 4350 },
  ]);

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const getStatusIcon = (status) => {
    switch(status) {
      case 'completed': return <CheckCircle size={14} color="#059669" />;
      // case 'pending': return <Clock size={14} color="#d97706" />;
      case 'shipped': return <Truck size={14} color="#2563eb" />;
      default: return <MoreVertical size={14} />;
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'completed': return '#d1fae5';
      case 'pending': return '#fef3c7';
      case 'shipped': return '#dbeafe';
      default: return '#f3f4f6';
    }
  };

  const getStatusTextColor = (status) => {
    switch(status) {
      case 'completed': return '#065f46';
      case 'pending': return '#92400e';
      case 'shipped': return '#1e40af';
      default: return '#374151';
    }
  };

  // Calculate additional stats
  const averageOrderValue = stats.totalSales / stats.totalOrders;
  const orderCompletionRate = (recentOrders.filter(o => o.status === 'completed').length / recentOrders.length) * 100;

  if (!user || user.role !== 'admin') {
    return (
      <div className="empty-state">
        <div className="empty-icon">🚫</div>
        <h2 className="empty-title">Access Denied</h2>
        <p className="empty-text">You don't have permission to access this page.</p>
        <Link to="/login/admin" className="btn btn-primary">
          Admin Login
        </Link>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
        <p>Loading dashboard data...</p>
      </div>
    );
  }

  return (
    <div className="admin-dashboard">


      <div className="container">
        {/* Dashboard Header */}
        <div className="dashboard-header">
          <h1 className="dashboard-title">Welcome back, {user.name}!</h1>
          <p className="dashboard-subtitle">
            Here's what's happening with your store today. You have <strong>{recentOrders.filter(o => o.status === 'pending').length}</strong> pending orders.
          </p>
        </div>

        <div className="admin-stats-grid">
          <div className="admin-stat-card">
            <div className="admin-stat-icon" style={{ background: '#dbeafe', color: '#2563eb' }}>
              <DollarSign size={24} />
            </div>
            <div className="admin-stat-info">
              <div>
                <div className="admin-stat-value">${stats.totalSales.toLocaleString()}</div>
                <div className="admin-stat-label">Total Sales</div>
              </div>
              <div className="admin-stat-change positive">
                <TrendingUp size={16} />
                {stats.monthlyGrowth}%
              </div>
            </div>
          </div>

          <div className="admin-stat-card">
            <div className="admin-stat-icon" style={{ background: '#f0f9ff', color: '#0ea5e9' }}>
              <ShoppingCart size={24} />
            </div>
            <div className="admin-stat-info">
              <div>
                <div className="admin-stat-value">{stats.totalOrders}</div>
                <div className="admin-stat-label">Total Orders</div>
              </div>
              <div className="admin-stat-change positive">
                <TrendingUp size={16} />
                8.2%
              </div>
            </div>
          </div>

          <div className="admin-stat-card">
            <div className="admin-stat-icon" style={{ background: '#fef3c7', color: '#d97706' }}>
              <Package size={24} />
            </div>
            <div className="admin-stat-info">
              <div>
                <div className="admin-stat-value">{stats.totalProducts}</div>
                <div className="admin-stat-label">Products</div>
              </div>
              <div className="admin-stat-change positive">
                <TrendingUp size={16} />
                5.3%
              </div>
            </div>
          </div>

          <div className="admin-stat-card">
            <div className="admin-stat-icon" style={{ background: '#f3e8ff', color: '#7c3aed' }}>
              <Users size={24} />
            </div>
            <div className="admin-stat-info">
              <div>
                <div className="admin-stat-value">{stats.totalCustomers}</div>
                <div className="admin-stat-label">Customers</div>
              </div>
              <div className="admin-stat-change positive">
                <TrendingUp size={16} />
                3.1%
              </div>
            </div>
          </div>
        </div>

        {/* Charts and Recent Orders */}
        <div className="dashboard-section">
          <div className="section-header">
            <h2 className="section-title">Sales Overview</h2>
            <div className="section-actions">
              <select className="month-filter">
                <option>Last 12 Months</option>
                <option>Last 6 Months</option>
                <option>Last 3 Months</option>
                <option>This Year</option>
              </select>
            </div>
          </div>
          
          <div className="chart-container">
            {/* Simple Bar Chart Representation */}
            <div style={{ 
              padding: '20px',
              background: '#f9fafb', 
              borderRadius: '12px', 
              height: '100%'
            }}>
              <div style={{ 
                display: 'flex', 
                alignItems: 'flex-end', 
                height: '300px',
                gap: '20px',
                justifyContent: 'center',
                marginTop: '40px'
              }}>
                {monthlyData.slice(-6).map((month, index) => (
                  <div key={month.month} style={{ 
                    display: 'flex', 
                    flexDirection: 'column', 
                    alignItems: 'center',
                    gap: '10px'
                  }}>
                    <div style={{
                      width: '40px',
                      height: `${(month.sales / 50000) * 250}px`,
                      background: 'linear-gradient(to top, #2563eb, #60a5fa)',
                      borderRadius: '6px 6px 0 0',
                      position: 'relative'
                    }}>
                      <div style={{
                        position: 'absolute',
                        top: '-25px',
                        left: '50%',
                        transform: 'translateX(-50%)',
                        fontSize: '12px',
                        fontWeight: '600',
                        color: '#2563eb'
                      }}>
                        ${(month.sales / 1000).toFixed(0)}k
                      </div>
                    </div>
                    <div style={{ 
                      fontSize: '14px', 
                      color: '#6b7280',
                      fontWeight: '600'
                    }}>
                      {month.month}
                    </div>
                  </div>
                ))}
              </div>
              <div style={{ 
                textAlign: 'center', 
                marginTop: '30px',
                color: '#6b7280',
                fontSize: '14px'
              }}>
                <p>Total Sales Last 6 Months: <strong>${monthlyData.slice(-6).reduce((sum, month) => sum + month.sales, 0).toLocaleString()}</strong></p>
                <p>Total Orders: <strong>{monthlyData.slice(-6).reduce((sum, month) => sum + month.orders, 0)}</strong></p>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Orders & Top Products Side by Side */}
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: '1fr 1fr', 
          gap: '32px',
          marginBottom: '40px'
        }}>
          {/* Recent Orders */}
          <div className="dashboard-section">
            <div className="section-header">
              <h2 className="section-title">Recent Orders</h2>
              <Link to="/admin/orders" className="btn btn-primary btn-small">
                View All ({recentOrders.length})
              </Link>
            </div>
            
            <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
              <table className="recent-orders-table">
                <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Status</th>
                    {/* <th>Action</th> */}
                  </tr>
                </thead>
                <tbody>
                  {recentOrders.map((order) => (
                    <tr key={order.id}>
                      <td>
                        <strong>{order.id}</strong>
                        <div style={{ fontSize: '12px', color: '#6b7280' }}>
                          {order.date}
                        </div>
                      </td>
                      <td>{order.customer}</td>
                      <td>
                        <strong>${order.amount.toFixed(2)}</strong>
                      </td>
                      <td>
                        <span 
                          className="status-badge"
                          style={{
                            background: getStatusColor(order.status),
                            color: getStatusTextColor(order.status),
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px'
                          }}
                        >
                          {getStatusIcon(order.status)}
                          {order.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Top Selling Products */}
          <div className="dashboard-section">
            <div className="section-header">
              <h2 className="section-title">Top Products</h2>
            </div>
            
            <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
              <table className="recent-orders-table">
                <thead>
                  <tr>
                    <th>Product</th>
                    <th>Category</th>
                    <th>Sales</th>
                    <th>Revenue</th>
                  </tr>
                </thead>
                <tbody>
                  {topProducts.map((product) => (
                    <tr key={product.id}>
                      <td>
                        <strong>{product.name}</strong>
                      </td>
                      <td>
                        <span style={{
                          background: '#f3f4f6',
                          padding: '4px 8px',
                          borderRadius: '12px',
                          fontSize: '12px',
                          color: '#6b7280'
                        }}>
                          {product.category}
                        </span>
                      </td>
                      <td>
                        <strong>{product.sales}</strong>
                      </td>
                      <td>
                        <strong style={{ color: '#059669' }}>
                          ${product.revenue.toLocaleString()}
                        </strong>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="dashboard-section">
          <h2 className="section-title" style={{ marginBottom: '32px' }}>Quick Actions</h2>
          <div className="admin-quick-actions">
            <Link to="/admin/products/new" className="admin-action-card">
              <div className="admin-action-icon">
                <PlusCircle size={28} />
              </div>
              <h3 className="admin-action-title">Add Product</h3>
              <p className="admin-action-desc">Create new product listing</p>
            </Link>
            
            <Link to="/admin/orders" className="admin-action-card">
              <div className="admin-action-icon">
                <ShoppingCart size={28} />
              </div>
              <h3 className="admin-action-title">Manage Orders</h3>
              <p className="admin-action-desc">Process and track orders</p>
            </Link>
            
            <Link to="/admin/reports" className="admin-action-card">
              <div className="admin-action-icon">
                <FileText size={28} />
              </div>
              <h3 className="admin-action-title">Generate Report</h3>
              <p className="admin-action-desc">Download sales reports</p>
            </Link>
            
            <Link to="/admin/settings" className="admin-action-card">
              <div className="admin-action-icon">
                <Settings size={28} />
              </div>
              <h3 className="admin-action-title">Store Settings</h3>
              <p className="admin-action-desc">Configure store options</p>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;