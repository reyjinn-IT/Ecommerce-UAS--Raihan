// src/pages/Checkout.js - UPDATE handleSubmit
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, CreditCard, Package, User, MapPin, Phone, Mail } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const Checkout = () => {
  const { cartItems, getTotalPrice, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    fullName: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    address: user?.address || '',
    city: '',
    postalCode: '',
    country: '',
    paymentMethod: 'credit-card'
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.fullName || !formData.email || !formData.address) {
      alert('Please fill in all required fields');
      return;
    }

    // Buat order object
    const subtotal = getTotalPrice();
    const shipping = subtotal > 50 ? 0 : 5;
    const tax = subtotal * 0.1;
    const total = subtotal + shipping + tax;

    const order = {
      id: `ORD${Date.now()}`,
      userId: user?.id || null,
      customerName: formData.fullName,
      customerEmail: formData.email,
      items: cartItems.map(item => ({
        productId: item.id,
        title: item.title,
        price: item.price,
        quantity: item.quantity,
        image: item.image
      })),
      subtotal: subtotal,
      shipping: shipping,
      tax: tax,
      total: total,
      status: 'pending',
      paymentMethod: formData.paymentMethod,
      shippingAddress: `${formData.address}, ${formData.city}, ${formData.postalCode}, ${formData.country}`,
      orderDate: new Date().toISOString()
    };

    // Simpan ke localStorage
    const existingOrders = JSON.parse(localStorage.getItem('orders') || '[]');
    localStorage.setItem('orders', JSON.stringify([...existingOrders, order]));
    
    // Clear cart
    clearCart();
    
    // Redirect dan show alert
    alert(`🎉 Order Successful!\nOrder ID: ${order.id}\nTotal: $${total.toFixed(2)}\n\nOrder has been recorded in admin dashboard.`);
    navigate('/');
  };

  const subtotal = getTotalPrice();
  const shipping = subtotal > 50 ? 0 : 5;
  const tax = subtotal * 0.1;
  const total = subtotal + shipping + tax;

  return (
    <div>
      <Link to="/cart" className="btn btn-secondary mb-6" style={{ display: 'inline-flex', alignItems: 'center', textDecoration: 'none' }}>
        <ArrowLeft size={20} style={{ marginRight: '8px' }} />
        Back to Cart
      </Link>
      <h1 className="text-3xl font-bold mb-2">Checkout</h1>
      <p className="text-gray-600 mb-8">Complete your purchase with secure checkout</p>
      
      <div className="checkout-container">
        <div className="checkout-form-section">
          <h2 className="checkout-title mb-6">Shipping Information</h2>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-8">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <User size={20} style={{ marginRight: '8px' }} />
                Personal Details
              </h3>
              
              <div className="form-group">
                <label className="form-label">Full Name *</label>
                <input
                  type="text"
                  name="fullName"
                  className="form-input"
                  placeholder="John Doe"
                  value={formData.fullName}
                  onChange={handleInputChange}
                  required
                />
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Email Address *</label>
                  <input
                    type="email"
                    name="email"
                    className="form-input"
                    placeholder="john@example.com"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label className="form-label">Phone Number</label>
                  <input
                    type="tel"
                    name="phone"
                    className="form-input"
                    placeholder="+1 234 567 8900"
                    value={formData.phone}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <MapPin size={20} style={{ marginRight: '8px' }} />
                Shipping Address
              </h3>
              
              <div className="form-group">
                <label className="form-label">Address *</label>
                <input
                  type="text"
                  name="address"
                  className="form-input"
                  placeholder="123 Main Street"
                  value={formData.address}
                  onChange={handleInputChange}
                  required
                />
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">City</label>
                  <input
                    type="text"
                    name="city"
                    className="form-input"
                    placeholder="New York"
                    value={formData.city}
                    onChange={handleInputChange}
                  />
                </div>
                
                <div className="form-group">
                  <label className="form-label">Postal Code</label>
                  <input
                    type="text"
                    name="postalCode"
                    className="form-input"
                    placeholder="10001"
                    value={formData.postalCode}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
              
              <div className="form-group">
                <label className="form-label">Country</label>
                <input
                  type="text"
                  name="country"
                  className="form-input"
                  placeholder="United States"
                  value={formData.country}
                  onChange={handleInputChange}
                />
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <CreditCard size={20} style={{ marginRight: '8px' }} />
                Payment Method
              </h3>
              
              <div className="space-y-3">
                <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="credit-card"
                    checked={formData.paymentMethod === 'credit-card'}
                    onChange={handleInputChange}
                    className="mr-3"
                  />
                  <div>
                    <span className="font-medium">Credit / Debit Card</span>
                    <p className="text-sm text-gray-600 mt-1">Pay with your card securely</p>
                  </div>
                </label>
                
                <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="paypal"
                    checked={formData.paymentMethod === 'paypal'}
                    onChange={handleInputChange}
                    className="mr-3"
                  />
                  <div>
                    <span className="font-medium">PayPal</span>
                    <p className="text-sm text-gray-600 mt-1">Fast and secure online payments</p>
                  </div>
                </label>
                
                <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="cod"
                    checked={formData.paymentMethod === 'cod'}
                    onChange={handleInputChange}
                    className="mr-3"
                  />
                  <div>
                    <span className="font-medium">Cash on Delivery</span>
                    <p className="text-sm text-gray-600 mt-1">Pay when you receive your order</p>
                  </div>
                </label>
              </div>
            </div>

            <button
              type="submit"
              className="w-full btn btn-primary py-4 text-lg font-semibold"
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' }}
            >
              <Package size={22} />
              Complete Order - ${total.toFixed(2)}
            </button>
          </form>
        </div>

        <div className="checkout-summary">
          <h2 className="checkout-title mb-6">Order Summary</h2>
          
          <div className="mb-6">
            {cartItems.map(item => (
              <div key={item.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg mb-3">
                <div>
                  <p className="font-medium">{item.title}</p>
                  <p className="text-sm text-gray-600">Quantity: {item.quantity}</p>
                </div>
                <p className="font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
              </div>
            ))}
          </div>
          
          <div className="mb-6">
            <div className="summary-row">
              <span>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="summary-row">
              <span>Shipping</span>
              <span className={shipping === 0 ? "text-green-600 font-semibold" : ""}>
                {shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}
              </span>
            </div>
            <div className="summary-row">
              <span>Tax (10%)</span>
              <span>${tax.toFixed(2)}</span>
            </div>
            <div className="summary-row summary-total">
              <span>Total</span>
              <span className="total-price">${total.toFixed(2)}</span>
            </div>
          </div>
          
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
            <div className="flex items-center mb-2">
              <CreditCard size={18} className="text-blue-600 mr-2" />
              <span className="font-medium text-blue-700">Secure Payment</span>
            </div>
            <p className="text-sm text-blue-600">
              Your payment information is encrypted and secure. We don't store your credit card details.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;